import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import statistics
import os
import torch
import numpy as np

# Set plot style and parameters
plt.style.use(['ggplot'])
plt.rcParams["text.usetex"] = False
plt.rcParams['figure.figsize'] = 6, 2

# Create a directory for saving plots
os.makedirs('plots', exist_ok=True)

def smooth(y, box_pts=1):
    # Function to smooth the input signal using a box filter
    box = np.ones(box_pts) / box_pts
    y_smooth = np.convolve(y, box, mode='same')
    return y_smooth

def plotter(name, y_true, y_pred, ascore, labels):
    # Function to plot true values, predicted values, anomaly scores, and labels
    if 'TAD' in name:
        y_true = torch.roll(y_true, 1, 0)

    # Create a directory for saving plots specific to the current 'name'
    os.makedirs(os.path.join('plots', name), exist_ok=True)

    # Create a PDF file for saving multiple plots
    pdf = PdfPages(f'plots/{name}/output.pdf')

    for dim in range(y_true.shape[1]):
        # Extract data for the current dimension
        y_t, y_p, l, a_s = y_true[:, dim], y_pred[:, dim], labels[:, dim], ascore[:, dim]

        # Create subplots for true values, predicted values, and anomaly scores
        fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
        ax1.set_ylabel('Value')
        ax1.set_title(f'Dimension = {dim}')

        # Plot true and predicted values with labels
        ax1.plot(smooth(y_t), linewidth=0.2, label='True')
        ax1.plot(smooth(y_p), '-', alpha=0.6, linewidth=0.3, label='Predicted')
        ax3 = ax1.twinx()
        ax3.plot(l, '--', linewidth=0.3, alpha=0.5)
        ax3.fill_between(np.arange(l.shape[0]), l, color='blue', alpha=0.3)
        
        # Add legend to the first subplot (true and predicted values)
        if dim == 0:
            ax1.legend(ncol=2, bbox_to_anchor=(0.6, 1.02))

        # Plot anomaly scores in the second subplot
        ax2.plot(smooth(a_s), linewidth=0.2, color='g')
        ax2.set_xlabel('Timestamp')
        ax2.set_ylabel('Anomaly Score')

        # Save the current figure to the PDF file
        pdf.savefig(fig)
        plt.close()

    # Close the PDF file after saving all the figures
    pdf.close()
