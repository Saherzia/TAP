from math import log, floor
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tqdm
from scipy.optimize import minimize

# Colors for plot
DEEP_SAFFRON = '#FF9933'
AIR_FORCE_BLUE = '#5D8AA8'

class SPOT:
    def __init__(self, detection_level=1e-4):
        # Initialize the SPOT object with a detection level
        self.proba = detection_level
        self.extreme_quantile = None
        self.data = None
        self.init_data = None
        self.init_threshold = None
        self.peaks = None
        self.n = 0
        self.Nt = 0

    def __str__(self):
        # String representation of the SPOT object
        s = 'Streaming Peaks-Over-Threshold Object\n'
        s += f'Detection level q = {self.proba}\n'

        if self.data is not None:
            s += f'Data imported: Yes\n'
            s += f'\tInitialization: {self.init_data.size} values\n'
            s += f'\tStream: {self.data.size} values\n'
        else:
            s += 'Data imported: No\n'
            return s

        if self.n == 0:
            s += 'Algorithm initialized: No\n'
        else:
            s += 'Algorithm initialized: Yes\n'
            s += f'\tInitial threshold: {self.init_threshold}\n'

            r = self.n - self.init_data.size
            if r > 0:
                s += f'Algorithm run: Yes\n'
                s += f'\tNumber of observations: {r} ({100 * r / self.n:.2f} %)\n'
            else:
                s += f'\tNumber of peaks: {self.Nt}\n'
                s += f'\tExtreme quantile: {self.extreme_quantile}\n'
                s += 'Algorithm run: No\n'
        return s

    def fit(self, init_data, data):
        # Fit the SPOT model with initialization and streaming data
        self.data = np.asarray(data)
        self.init_data = np.asarray(init_data)

    def add(self, data):
        # Add more data to the streaming SPOT model
        self.data = np.append(self.data, np.asarray(data))

    def initialize(self, level=0.98, min_extrema=False, verbose=True):
        # Initialize the SPOT algorithm with a specified quantile level
        if min_extrema:
            self.init_data = -self.init_data
            self.data = -self.data
            level = 1 - level

        level = level - floor(level)
        n_init = self.init_data.size

        S = np.sort(self.init_data)
        self.init_threshold = S[int(level * n_init)]

        self.peaks = self.init_data[self.init_data > self.init_threshold] - self.init_threshold
        self.Nt = self.peaks.size
        self.n = n_init

        if verbose:
            print(f'Initial threshold: {self.init_threshold}')
            print(f'Number of peaks: {self.Nt}')
            print('Grimshaw maximum log-likelihood estimation ... ', end='')

        g, s, l = self._grimshaw()
        self.extreme_quantile = self._quantile(g, s)

        if verbose:
            print('[done]')
            print(f'\tγ = {g}')
            print(f'\tσ = {s}')
            print(f'\tL = {l}')
            print(f'Extreme quantile (probability = {self.proba}): {self.extreme_quantile}')

    @staticmethod
    def _roots_finder(fun, jac, bounds, npoints, method):
        # Find roots of a function within given bounds using various methods
        if method == 'regular':
            step = (bounds[1] - bounds[0]) / (npoints + 1)
            if step == 0:
                bounds, step = (0, 1e-4), 1e-5
            X0 = np.arange(bounds[0] + step, bounds[1], step)
        elif method == 'random':
            X0 = np.random.uniform(bounds[0], bounds[1], npoints)

        def obj_fun(X, f, jac):
            g = 0
            j = np.zeros(X.shape)
            i = 0
            for x in X:
                fx = f(x)
                g = g + fx ** 2
                j[i] = 2 * fx * jac(x)
                i = i + 1
            return g, j

        opt = minimize(lambda X: obj_fun(X, fun, jac), X0, method='L-BFGS-B', jac=True, bounds=[bounds] * len(X0))
        X = opt.x
        np.round(X, decimals=5)
        return np.unique(X)

    @staticmethod
    def _log_likelihood(Y, gamma, sigma):
        # Calculate log-likelihood for given parameters and data
        n = Y.size
        if gamma != 0:
            tau = gamma / sigma
            L = -n * log(sigma) - (1 + (1 / gamma)) * (np.log(1 + tau * Y)).sum()
        else:
            L = n * (1 + log(Y.mean()))
        return L

    def _grimshaw(self, epsilon=1e-8, n_points=10):
        # Perform Grimshaw maximum log-likelihood estimation
        def u(s):
            return 1 + np.log(s).mean()

        def v(s):
            return np.mean(1 / s)

        def w(Y, t):
            s = 1 + t * Y
            us = u(s)
            vs = v(s)
            return us * vs - 1

        def jac_w(Y, t):
            s = 1 + t * Y
            us = u(s)
            vs = v(s)
            jac_us = (1 / t) * (1 - vs)
            jac_vs = (1 / t) * (-vs + np.mean(1 / s ** 2))
            return us * jac_vs + vs * jac_us

        Ym = self.peaks.min()
        YM = self.peaks.max()
        Ymean = self.peaks.mean()

        a = -1 / YM
        if abs(a) < 2 * epsilon:
            epsilon = abs(a) / n_points

        a = a + epsilon
        b = 2 * (Ymean - Ym) / (Ymean * Ym)
        c = 2 * (Ymean - Ym) / (Ym ** 2)

        left_zeros = self._roots_finder(lambda t: w(self.peaks, t),
                                        lambda t: jac_w(self.peaks, t),
                                        (a + epsilon, -epsilon),
                                        n_points, 'regular')

        right_zeros = self._roots_finder(lambda t: w(self.peaks, t),
                                         lambda t: jac_w(self.peaks, t),
                                         (b, c),
                                         n_points, 'regular')

        zeros = np.concatenate((left_zeros, right_zeros))
        gamma_best = 0
        sigma_best = Ymean
        ll_best = self._log_likelihood(self.peaks, gamma_best, sigma_best)

        for z in zeros:
            gamma = u(1 + z * self.peaks) - 1
            sigma = gamma / z
            ll = self._log_likelihood(self.peaks, gamma, sigma)
            if ll > ll_best:
                gamma_best = gamma
                sigma_best = sigma
                ll_best = ll

        return gamma_best, sigma_best, ll_best

    def _quantile(self, gamma, sigma):
        # Calculate the quantile for the given parameters
        r = self.n * self.proba / self.Nt
        if gamma != 0:
            return self.init_threshold + (sigma / gamma) * (pow(r, -gamma) - 1)
        else:
            return self.init_threshold - sigma * log(r)

    def run(self, with_alarm=True, dynamic=True):
        # Run the SPOT algorithm on the streaming data
        if self.n > self.init_data.size:
            print('Warning: The algorithm seems to have already been run; you should initialize before running again')
            return {}

        th = []
        alarm = []

        for i in range(self.data.size):
            if not dynamic:
                if self.data[i] > self.init_threshold and with_alarm:
                    self.extreme_quantile = self.init_threshold
                    alarm.append(i)
            else:
                if self.data[i] > self.extreme_quantile:
                    if with_alarm:
                        alarm.append(i)
                    else:
                        self.peaks = np.append(self.peaks, self.data[i] - self.init_threshold)
                        self.Nt += 1
                        self.n += 1

                        g, s, l = self._grimshaw()
                        self.extreme_quantile = self._quantile(g, s)

                elif self.data[i] > self.init_threshold:
                    self.peaks = np.append(self.peaks, self.data[i] - self.init_threshold)
                    self.Nt += 1
                    self.n += 1

                    g, s, l = self._grimshaw()
                    self.extreme_quantile = self._quantile(g, s)
                else:
                    self.n += 1

            th.append(self.extreme_quantile)

        return {'thresholds': th, 'alarms': alarm}

    def plot(self, run_results, with_alarm=True):
        # Plot the streaming data along with thresholds and alarms
        x = range(self.data.size)
        K = run_results.keys()
        fig = []

        ts_fig, = plt.plot(x, self.data, color='blue')
        fig.append(ts_fig)

        if 'thresholds' in K:
            th = run_results['thresholds']
            th_fig, = plt.plot(x, th, color='orange', lw=2, ls='dashed')
            fig.append(th_fig)

        if with_alarm and 'alarms' in K:
            alarm = run_results['alarms']
            al_fig = plt.scatter(alarm, self.data[alarm], color='red')
            fig.append(al_fig)

        plt.xlim((0, self.data.size))
        plt.show()

        return fig
