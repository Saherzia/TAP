import matplotlib.pyplot as plt
import os
from src.constants import *  # Assuming constants are defined in the src module
import pandas as pd
import numpy as np

class color:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    RED = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def plot_accuracies(accuracy_list, folder):
    # Create directory for plots if it doesn't exist
    os.makedirs(f'plots/{folder}/', exist_ok=True)

    # Extract training accuracy and learning rates from the accuracy_list
    trainAcc = [i[0] for i in accuracy_list]
    lrs = [i[1] for i in accuracy_list]

    # Plotting the training loss and learning rate on the same graph
    plt.xlabel('Epochs')
    plt.ylabel('Average Training Loss')
    plt.plot(range(len(trainAcc)), trainAcc, label='Average Training Loss', linewidth=1, linestyle='-', marker='.')
    plt.twinx()
    plt.plot(range(len(lrs)), lrs, label='Learning Rate', color='r', linewidth=1, linestyle='--', marker='.')
    
    # Save the plot to a PDF file
    plt.savefig(f'plots/{folder}/training-graph.pdf')

    # Clear the plot for the next use
    plt.clf()

def cut_array(percentage, arr):
    # Display a message indicating the percentage of data being sliced
    print(f'{color.BOLD}Slicing dataset to {int(percentage*100)}%{color.ENDC}')

    # Calculate the midpoint and window size for slicing
    mid = round(arr.shape[0] / 2)
    window = round(arr.shape[0] * percentage * 0.5)

    # Return the sliced array
    return arr[mid - window : mid + window, :]

def getresults2(df, result):
    # Initialize a dictionary to store results
    results2, df1, df2 = {}, df.sum(), df.mean()

    # Extract counts of true positive, false positive, etc.
    for a in ['FN', 'FP', 'TP', 'TN']:
        results2[a] = df1[a]

    # Extract precision and recall and calculate f1 score
    for a in ['precision', 'recall']:
        results2[a] = df2[a]

    results2['f1*'] = 2 * results2['precision'] * results2['recall'] / (results2['precision'] + results2['recall'])

    # Return the results dictionary
    return results2
