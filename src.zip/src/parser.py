# Importing the argparse module for handling command-line arguments
import argparse

# Creating an ArgumentParser object to handle command-line arguments
parser = argparse.ArgumentParser(description='Time-Series Anomaly Detection')

# Adding command-line arguments to the parser

# Argument for specifying the dataset, with a default value of 'synthetic'
parser.add_argument('--dataset', 
                    metavar='-d', 
                    type=str, 
                    required=False,
                    default='NAB',
                    help="dataset from ['SMD', 'NAB', 'SMAP', 'MSL', 'SWaT']")

# Argument for specifying the model, with a default value of 'LSTM_Multivariate'
parser.add_argument('--model', 
                    metavar='-m', 
                    type=str, 
                    required=False,
                    default='TAD',
                    help="model name from ['TAD', 'TAD_Only']")

# Argument for triggering a test mode
parser.add_argument('--test', 
                    action='store_true', 
                    help="test the model")

# Argument for triggering a retrain mode
parser.add_argument('--retrain', 
                    action='store_true', 
                    help="retrain the model")

# Parsing the command-line arguments
args = parser.parse_args()

