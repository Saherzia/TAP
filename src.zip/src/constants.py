from src.parser import *
from src.folderconstants import *

# Threshold parameters for different datasets
lm_d = {
    'SMD':  (0.99995, 1.06),
    'SWaT':  (0.993, 1),
    'SMAP': (0.98, 1),
    'MSL': (0.999, 1.04),
    'NAB': (0.99, 1),
}

# Selecting the appropriate threshold based on the dataset and model type
lm = lm_d[args.dataset]

# Hyperparameters for different datasets
lr_d = {
    'SMD': 0.0001,
    'SWaT': 0.008,
    'SMAP': 0.001,
    'MSL': 0.002,
    'NAB': 0.009,
}

# Selecting the appropriate learning rate based on the dataset
lr = lr_d[args.dataset]

# Debugging parameters for different datasets
percentiles = {
    'SMD': (98, 2000),
    'SWaT': (95, 10),
    'SMAP': (97, 5000),
    'MSL': (97, 150),
    'NAB': (98, 2),
}

# Selecting the appropriate percentile based on the dataset
cvp = percentiles[args.dataset][1]

# Initializing empty list for predictions
preds = []

# Debugging parameter
debug = 9  # You can modify this value as needed
