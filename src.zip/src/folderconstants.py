# Data folders
output_folder = 'processed'  # Folder to store processed data
data_folder = 'data'        # Folder containing raw data
