import torch
import torch.nn as nn
import math
from torch.nn import TransformerEncoder, TransformerEncoderLayer, TransformerDecoder, TransformerDecoderLayer

# Positional Encoding class to add positional information to the input sequences
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)

        # Create positional encodings
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * -(math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)

# Transformer-based Adversarial Perturbations model
class TAD(nn.Module):
    def __init__(self, feats, lr=0.001):
        super(TAD, self).__init__()
        self.name = 'TAD'
        self.lr = lr
        self.batch = 128
        self.n_feats = feats
        self.n_window = 5
        self.n = self.n_feats * self.n_window
        self.pos_encoder = PositionalEncoding(2 * feats, 0.1, self.n_window)

        # Customized Encoder Layer
        encoder_layers = TransformerEncoderLayer(
            d_model=2 * feats,
            nhead=feats,
            dim_feedforward=64,  #  feedforward dimension size
            dropout=0.1
        )
        self.transformer_encoder = TransformerEncoder(encoder_layers, num_layers=1)  # encoder layers

        # Customized Decoder Layer
        decoder_layers = TransformerDecoderLayer(
            d_model=2 * feats,
            nhead=feats,
            dim_feedforward=64,  # feedforward dimension size
            dropout=0.1
        )
        self.transformer_decoder = TransformerDecoder(decoder_layers, num_layers=1)  # decoder layers

        self.fcn = nn.Sequential(nn.Linear(2 * feats, feats), nn.Sigmoid())

    def encode(self, src, c, tgt):
        src = torch.cat((src, c), dim=2)
        src = src * math.sqrt(self.n_feats)
        src = self.pos_encoder(src)
        memory = self.transformer_encoder(src)
        tgt = tgt.repeat(1, 1, 2)
        return tgt, memory

    def generate_adversarial_perturbations(self, src, tgt):
        src.requires_grad = True
        predictions = self.fcn(self.transformer_decoder(*self.encode(src, torch.zeros_like(src), tgt)))
        loss = nn.MSELoss()(predictions, tgt)
        gradients = torch.autograd.grad(loss, src)[0]
        normalized_gradients = gradients / torch.norm(gradients)
        epsilon = 0.01
        perturbations = epsilon * normalized_gradients
        return perturbations

    def forward(self, src, tgt):
        c = torch.zeros_like(src)

        # Generate adversarial perturbations
        perturbations = self.generate_adversarial_perturbations(src, tgt)

        # Apply perturbations to the input
        src_perturbed = src + perturbations

        # Forward pass on the perturbed input
        x = self.fcn(self.transformer_decoder(*self.encode(src_perturbed, c, tgt)))

        return x

# Basic Transformer-based model

class TAD_Only(nn.Module):
    def __init__(self, feats, lr=0.001):
        super(TAD_Only, self).__init__()
        self.name = 'TAD_Only'
        self.lr = lr
        self.batch = 128
        self.n_feats = feats
        self.n_window = 10
        self.n = self.n_feats * self.n_window
        self.pos_encoder = PositionalEncoding(2 * feats, 0.1, self.n_window)
       
        # Encoder Layer
        encoder_layers = TransformerEncoderLayer(
            d_model=2 * feats,
            nhead=feats,
            dim_feedforward=64,  # Changed the dim_feedforward size
            dropout=0.1
        )
        self.transformer_encoder = TransformerEncoder(encoder_layers, num_layers=1)  #encoder layers


        # Decoder Layer
        decoder_layers = TransformerDecoderLayer(
            d_model=2 * feats,
            nhead=feats,
            dim_feedforward=64,  # Changed the dim_feedforward size
            dropout=0.1
        )
        self.transformer_decoder = TransformerDecoder(decoder_layers, num_layers=1)  #decoder layers


        self.fcn = nn.Sequential(nn.Linear(2 * feats, feats), nn.Sigmoid())


    def encode(self, src, c, tgt):
        src = torch.cat((src, c), dim=2)
        src = src * math.sqrt(self.n_feats)
        src = self.pos_encoder(src)
        memory = self.transformer_encoder(src)
        tgt = tgt.repeat(1, 1, 2)
        return tgt, memory
    def forward(self, src, tgt):
        c = torch.zeros_like(src)
        x = self.fcn(self.transformer_decoder(*self.encode(src, c, tgt)))
        return x




