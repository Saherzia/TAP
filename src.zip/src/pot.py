import numpy as np
from src.spot import SPOT  # Import the SPOT class from the 'src.spot' module
from src.constants import *  # Import constants from the 'src.constants' module
from sklearn.metrics import roc_auc_score

def calc_point2point(predict, actual):
    # Calculate True Positives, True Negatives, False Positives, and False Negatives
    TP = np.sum(predict * actual)
    TN = np.sum((1 - predict) * (1 - actual))
    FP = np.sum(predict * (1 - actual))
    FN = np.sum((1 - predict) * actual)

    # Calculate precision, recall, and F1 score with smoothing to avoid division by zero
    precision = TP / (TP + FP + 0.00001)
    recall = TP / (TP + FN + 0.00001)
    f1 = 2 * precision * recall / (precision + recall + 0.00001)

    try:
        # Calculate ROC/AUC score using sklearn's roc_auc_score function
        roc_auc = roc_auc_score(actual, predict)
    except Exception as e:
        print(f"Error calculating ROC/AUC: {e}")
        roc_auc = 0

    return f1, precision, recall, TP, TN, FP, FN, roc_auc

def adjust_predicts(score, label, threshold=None, pred=None, calc_latency=False):
    if len(score) != len(label):
        raise ValueError("score and label must have the same length")

    score = np.asarray(score)
    label = np.asarray(label)
    latency = 0

    if threshold is not None:
        # Use threshold if provided
        predict = score > threshold
    elif pred is not None:
        # Use provided predictions if available
        predict = pred
    else:
        # Default to all zeros if no threshold or predictions are provided
        predict = np.zeros_like(score, dtype=bool)

    actual = label > 0.1  # Define anomaly threshold
    anomaly_state = False
    anomaly_count = 0

    for i in range(len(score)):
        if actual[i] and predict[i] and not anomaly_state:
            # Update anomaly state and count if a new anomaly is detected
            anomaly_state = True
            anomaly_count += 1
            for j in range(i, 0, -1):
                if not actual[j]:
                    break
                else:
                    if not predict[j]:
                        predict[j] = True
                        latency += 1
        elif not actual[i]:
            # Reset anomaly state when no anomaly is present
            anomaly_state = False
        if anomaly_state:
            # Extend anomaly prediction within the anomaly state
            predict[i] = True

    if calc_latency:
        return predict, latency / (anomaly_count + 1e-4)
    else:
        return predict

def calc_seq(score, label, threshold, calc_latency=False):
    if calc_latency:
        # Calculate point-to-point metrics and latency if requested
        predict, latency = adjust_predicts(score, label, threshold, calc_latency=calc_latency)
        t = list(calc_point2point(predict, label))
        t.append(latency)
        return t
    else:
        # Calculate point-to-point metrics only
        predict = adjust_predicts(score, label, threshold, calc_latency=calc_latency)
        return calc_point2point(predict, label)

def optimize_threshold(score, label, start, end=None, step_num=1, display_freq=1, verbose=True):
    from scipy.optimize import minimize_scalar

    if step_num is None or end is None:
        # If step_num or end is not provided, set them to default values
        end = start
        step_num = 1

    search_range = end - start

    def objective(threshold):
        # Define the objective function for threshold optimization
        return -calc_point2point(adjust_predicts(score, label, threshold), label)[0]

    result = minimize_scalar(objective, bounds=(start, end), method='bounded')
    best_threshold = result.x
    best_results = calc_point2point(adjust_predicts(score, label, best_threshold), label)

    return best_results, best_threshold

def pot_eval(init_score, score, label, q=1e-5, level=0.02):
    lms = lm[0]  # Assuming lm is a predefined variable
    while True:
        try:
            # Initialize and run the SPOT algorithm
            s = SPOT(q)
            s.fit(init_score, score)
            s.initialize(level=lms, min_extrema=False, verbose=False)
        except:
            lms = lms * 0.999  # Adjust level parameter if initialization fails
        else:
            break
    ret = s.run(dynamic=False)
    pot_th = np.mean(ret['thresholds']) * lm[1]  # Assuming lm is a predefined variable
    pred, p_latency = adjust_predicts(score, label, pot_th, calc_latency=True)
    p_t = calc_point2point(pred, label)
    return {
        'f1': p_t[0],
        'precision': p_t[1],
        'recall': p_t[2],
        'TP': p_t[3],
        'TN': p_t[4],
        'FP': p_t[5],
        'FN': p_t[6],
        'ROC/AUC': p_t[7],
        'threshold': pot_th,
    }, np.array(pred)
